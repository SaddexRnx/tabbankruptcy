import{c as p,f as j,j as e,R as f,r as i,D as m,g as k,e as g,S as v,L as N,t as S,a as y}from"./index-DvPXe3bN.js";/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=p("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C=p("Save",[["path",{d:"M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",key:"1c8476"}],["path",{d:"M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7",key:"1ydtos"}],["path",{d:"M7 3v4a1 1 0 0 0 1 1h7",key:"t51u73"}]]);function E(){const[a,s]=i.useState(m),[o,u]=i.useState(!1),d=a.language||"en",x=(t,h)=>S(d,t,h);i.useEffect(()=>{k(g,{}).then(t=>s({...m,...t}))},[]),i.useEffect(()=>{const t=a.theme==="system"?window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light":a.theme;document.documentElement.classList.toggle("dark",t==="dark"),document.documentElement.dir=d==="ar"?"rtl":"ltr"},[a.theme,d]);const n=t=>s(h=>({...h,...t})),b=async()=>{await y(g,a),u(!0),setTimeout(()=>u(!1),1600)};return e.jsxs("div",{className:"min-h-screen bg-white text-neutral-900 dark:bg-neutral-950 dark:text-neutral-50",children:[e.jsxs("div",{className:"mx-auto max-w-2xl px-6 py-10",children:[e.jsxs("header",{className:"flex items-center gap-3 mb-8",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl bg-neutral-900 dark:bg-white flex items-center justify-center",children:e.jsx(v,{size:18,className:"text-white dark:text-neutral-900"})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-xl font-semibold tracking-tight",children:"TabBankruptcy"}),e.jsx("p",{className:"text-xs text-neutral-500",children:x("settings")})]})]}),e.jsxs("div",{className:"space-y-8",children:[e.jsxs(c,{title:"Appearance",children:[e.jsx(r,{label:x("language"),children:e.jsx("select",{value:a.language,onChange:t=>n({language:t.target.value}),className:"input",children:N.map(t=>e.jsx("option",{value:t.code,children:t.label},t.code))})}),e.jsx(r,{label:"Theme",children:e.jsxs("select",{value:a.theme,onChange:t=>n({theme:t.target.value}),className:"input",children:[e.jsx("option",{value:"system",children:"System"}),e.jsx("option",{value:"light",children:"Light"}),e.jsx("option",{value:"dark",children:"Dark"})]})})]}),e.jsxs(c,{title:"Naming rules",children:[e.jsx(r,{label:"Session name prefix",children:e.jsx("input",{value:a.namePrefix,onChange:t=>n({namePrefix:t.target.value}),className:"input",placeholder:"Session"})}),e.jsx(r,{label:"Date format",children:e.jsxs("select",{value:a.dateFormat,onChange:t=>n({dateFormat:t.target.value}),className:"input",children:[e.jsx("option",{value:"short",children:"Short — Jul 24, 14:32"}),e.jsx("option",{value:"iso",children:"ISO — 2026-07-24 14:32"}),e.jsx("option",{value:"time",children:"Time only — 14:32"})]})}),e.jsxs("p",{className:"text-xs text-neutral-500",children:["Preview:"," ",e.jsx("span",{className:"font-mono",children:`${a.namePrefix||"Session"} — sample`})]})]}),e.jsxs(c,{title:"Confirmation",children:[e.jsx(l,{label:"Ask to name the session before closing tabs",checked:a.confirmBeforeClose,onChange:t=>n({confirmBeforeClose:t})}),e.jsx(l,{label:"Skip confirmation when using the keyboard shortcut",checked:a.skipConfirmOnShortcut,onChange:t=>n({skipConfirmOnShortcut:t})})]}),e.jsxs(c,{title:"Which tabs count",children:[e.jsx(l,{label:"Ignore pinned tabs",checked:a.ignorePinned,onChange:t=>n({ignorePinned:t})}),e.jsx(l,{label:"Ignore chrome://, edge://, brave://, about: pages",checked:a.ignoreChromeInternal,onChange:t=>n({ignoreChromeInternal:t})}),e.jsx(l,{label:"Ignore other extension pages",checked:a.ignoreExtensionPages,onChange:t=>n({ignoreExtensionPages:t})}),e.jsx(r,{label:"Exclude URLs containing (one per line)",children:e.jsx("textarea",{rows:4,value:a.excludePatterns,onChange:t=>n({excludePatterns:t.target.value}),className:"input font-mono text-xs",placeholder:`mail.google.com
localhost`})})]}),e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsxs("button",{onClick:b,className:"inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 font-semibold text-sm hover:opacity-90",children:[o?e.jsx(w,{size:14}):e.jsx(C,{size:14}),o?"Saved":"Save settings"]}),e.jsx("a",{href:"chrome://extensions/shortcuts",target:"_blank",rel:"noreferrer",className:"text-xs text-neutral-500 hover:underline",children:"Customize keyboard shortcuts →"})]})]})]}),e.jsx("style",{children:`
        .input {
          width: 100%;
          padding: 0.5rem 0.75rem;
          border-radius: 0.5rem;
          border: 1px solid rgb(229 229 229);
          background: white;
          font-size: 0.875rem;
          outline: none;
          color: inherit;
        }
        .dark .input {
          background: rgb(23 23 23);
          border-color: rgb(38 38 38);
        }
        .input:focus {
          border-color: rgb(23 23 23);
        }
        .dark .input:focus {
          border-color: white;
        }
      `})]})}function c({title:a,children:s}){return e.jsxs("section",{className:"space-y-3",children:[e.jsx("h2",{className:"text-sm font-semibold uppercase tracking-wide text-neutral-500",children:a}),e.jsx("div",{className:"space-y-3 rounded-xl border border-neutral-200 dark:border-neutral-800 p-4",children:s})]})}function r({label:a,children:s}){return e.jsxs("label",{className:"block space-y-1.5",children:[e.jsx("span",{className:"text-xs font-medium text-neutral-600 dark:text-neutral-400",children:a}),s]})}function l({label:a,checked:s,onChange:o}){return e.jsxs("label",{className:"flex items-center justify-between gap-4 cursor-pointer",children:[e.jsx("span",{className:"text-sm",children:a}),e.jsx("button",{type:"button",onClick:()=>o(!s),className:`relative w-10 h-6 rounded-full transition ${s?"bg-neutral-900 dark:bg-white":"bg-neutral-200 dark:bg-neutral-800"}`,children:e.jsx("span",{className:`absolute top-0.5 left-0.5 w-5 h-5 rounded-full transition-transform ${s?"translate-x-4 bg-white dark:bg-neutral-900":"bg-white dark:bg-neutral-500"}`})})]})}j.createRoot(document.getElementById("root")).render(e.jsx(f.StrictMode,{children:e.jsx(E,{})}));
